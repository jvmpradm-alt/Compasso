# Compasso da Banda — instalação própria

Este é o mesmo aplicativo que você já viu, agora independente do Claude. Depois de publicado, qualquer integrante abre por um link comum, no iPhone ou no Android, sem conta nenhuma. Só quem tem a conta de administrador cadastra e edita.

Tudo o que segue usa serviços gratuitos. Não é preciso cartão de crédito.

---

## O que você vai ter no fim

- Um endereço próprio, algo como `https://banda-exodus.web.app`
- Ícone na tela inicial do iPhone e do Android, abrindo em tela cheia, sem barra de navegador
- Dados compartilhados ao vivo entre todos os aparelhos
- Um APK para instalar no Android fora da loja, se quiser

Tempo estimado na primeira vez: 30 a 40 minutos.

---

## Parte 1 — Criar o projeto no Firebase

1. Abra `https://console.firebase.google.com` e entre com sua conta Google.
2. Clique em **Criar um projeto**. Nome sugerido: `banda-exodus`. Pode desativar o Google Analytics.
3. Na tela do projeto, clique no ícone **</>** (Web) para criar um app web. Apelido: `compasso`. **Não** marque Firebase Hosting agora.
4. Aparece um bloco de código com `apiKey`, `authDomain`, `projectId` e outros. **Deixe essa aba aberta**, você vai copiar esses valores no passo 8.

## Parte 2 — Ligar o login

5. No menu lateral, **Criar** → **Authentication** → **Vamos começar**.
6. Na aba **Sign-in method**, ative dois provedores:
   - **E-mail/senha** (só a primeira chave, não precisa do link por e-mail)
   - **Anônimo**
7. Vá em **Users** → **Adicionar usuário**. Ponha o seu e-mail e uma senha. **Esse é o login de administrador do app.** Anote a senha; ela é gerenciada aqui, não dentro do aplicativo.

## Parte 3 — Criar o banco

8. No menu lateral, **Criar** → **Firestore Database** → **Criar banco de dados**.
   - Modo: **produção**
   - Local: `southamerica-east1` (São Paulo)
   - As regras de acesso vão ser enviadas por você no passo 12, substituindo as padrão.

## Parte 4 — Preencher os seus dados no projeto

9. Abra o arquivo `public/config.js` num editor de texto (Bloco de Notas serve) e substitua cada `COLE_...` pelos valores da aba que ficou aberta no passo 4. Confirme que o seu e-mail de administrador está em `administradores`.
10. Abra `firestore.rules` e confirme o mesmo e-mail dentro da função `admin()`. **Os dois arquivos precisam ter os mesmos e-mails**: o `config.js` controla o que aparece na tela, e o `firestore.rules` é o bloqueio de verdade, feito no servidor.

## Parte 5 — Publicar

11. Instale o Node.js (`https://nodejs.org`, versão LTS). Depois abra o Prompt de Comando ou o Terminal e rode:

```
npm install -g firebase-tools
firebase login
```

12. Entre na pasta deste projeto (a que tem o `firebase.json`) e rode:

```
firebase use --add
firebase deploy
```

No `firebase use --add`, escolha o projeto que você criou e dê um apelido qualquer, por exemplo `banda`.

Ao terminar, o comando mostra o endereço: **Hosting URL**. Esse é o link do aplicativo. O `deploy` envia junto as regras do banco.

> Cada vez que você mudar algo no projeto, é só rodar `firebase deploy` de novo.

## Parte 6 — Instalar no celular

**iPhone (Safari, obrigatoriamente Safari)**
1. Abra o link no Safari.
2. Toque no botão de compartilhar, o quadrado com a flecha para cima.
3. Deslize e toque em **Adicionar à Tela de Início**.
4. Confirme. O ícone vermelho aparece na tela inicial e abre em tela cheia.

**Android (Chrome)**
1. Abra o link no Chrome.
2. Toque nos três pontos → **Instalar aplicativo** (ou **Adicionar à tela inicial**).
3. Confirme. Fica igual a um app instalado.

Mande o link no grupo da banda. Cada integrante faz isso no próprio aparelho, uma vez.

## Parte 7 — Gerar o APK do Android (opcional)

O caminho da Parte 6 já entrega um app instalado, e é o mais simples. Se você quer mesmo o arquivo `.apk` para instalar por WhatsApp ou pen drive:

1. Abra `https://www.pwabuilder.com` e cole o link do seu aplicativo.
2. Clique em **Package for stores** → **Android**.
3. Em opções, deixe **Signing key: create new** para gerar o APK já assinado.
4. Baixe o pacote. Dentro dele vem o `.apk`, o `.aab` (para a Play Store, se um dia quiser) e um arquivo `assetlinks.json`.
5. Copie o `assetlinks.json` para a pasta `public/.well-known/` deste projeto e rode `firebase deploy` outra vez. Sem esse passo, o app instalado mostra a barra de endereço no topo.
6. No celular, para instalar um APK de fora da loja, o Android pede para autorizar **instalar apps desconhecidos** para o aplicativo que está abrindo o arquivo. É normal e é reversível.

Guarde o arquivo da chave de assinatura que o PWABuilder gera. Sem ele, uma atualização futura do APK não instala em cima da versão antiga.

---

## Primeiro uso do aplicativo

1. Abra o link. Você entra como visitante, em modo acompanhamento.
2. Toque em **Entrar** no topo e use o e-mail e a senha do passo 7.
3. Cadastre os integrantes na aba **Banda**.
4. Em **Repertório** → **Importar planilha**, arraste a planilha do repertório. A prévia mostra o que é novo e o que já existe antes de gravar.
5. Marque os primeiros ensaios e cultos em **Agenda**, e monte o repertório de cada um.

## Quem pode o quê

| | Visitante com o link | Administrador |
|---|---|---|
| Ver agenda, repertório, tom, BPM, histórico e escala | sim | sim |
| Metrônomo e tap tempo | sim | sim |
| Sugerir hino e apoiar sugestão | sim | sim |
| Cadastrar, editar, apagar, importar, montar repertório e escala | não | sim |

Uma coisa importante para você decidir: no ajuste que veio configurado, **qualquer pessoa com o link consegue ler** os dados, e isso inclui telefone e e-mail que você cadastrar nos integrantes. Se preferir não expor contato, deixe esses campos em branco. Se quiser fechar a leitura também, o arquivo `firestore.rules` tem no fim o bloco **MODO FECHADO** pronto, comentado, com a instrução. Nesse modo cada integrante precisa de uma conta de e-mail e senha criada por você no Firebase.

## Custos e limites

O plano gratuito do Firebase (Spark) cobre com folga o uso de uma banda: 1 GiB de banco, 50 mil leituras e 20 mil gravações por dia, 10 GB de tráfego mensal na hospedagem. Uma banda de 15 pessoas consultando o repertório todo dia fica em uma fração disso. Não há cobrança automática: se estourar, o serviço para até o dia seguinte, não gera fatura.

## Se algo não funcionar

- **Abre em branco**: quase sempre é erro de digitação no `config.js`. Abra o app no computador, aperte F12, aba Console, e veja a mensagem.
- **Aparece "Banco não configurado"**: o `config.js` ainda tem algum `COLE_...`.
- **Entro com a senha certa e continua sem poder editar**: o e-mail em `config.js` e em `firestore.rules` está diferente do e-mail do usuário criado no passo 7. Confira maiúsculas e espaços.
- **"Missing or insufficient permissions"**: as regras não foram enviadas. Rode `firebase deploy` na pasta do projeto.
- **Mudei o app e o celular mostra a versão antiga**: feche o app, abra de novo. O `sw.js` guarda uma cópia local e troca sozinho na segunda abertura.

## Arquivos do projeto

```
firebase.json              configuração da hospedagem
firestore.rules            quem pode ler e escrever  << edite os e-mails
firestore.indexes.json     não precisa mexer
public/
  index.html               o aplicativo inteiro
  config.js                suas credenciais            << edite aqui
  bridge.js                ligação com o Firebase
  sw.js                    cache para abrir rápido
  manifest.webmanifest     nome e ícones do app
  icones/                  ícones do app
  .well-known/             destino do assetlinks.json do APK
```
