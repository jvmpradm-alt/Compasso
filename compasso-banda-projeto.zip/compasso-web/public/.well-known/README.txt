Coloque aqui o arquivo assetlinks.json que o PWABuilder gera quando você
empacota o APK para Android. Sem ele o aplicativo instalado mostra a barra
de endereço do navegador no topo. Depois de copiar o arquivo, rode de novo:
firebase deploy
